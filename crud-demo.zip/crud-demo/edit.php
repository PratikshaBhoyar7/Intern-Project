<?php
require 'db.php';

// To get client data
$id = $_GET['id'] ?? 0;
$result = mysqli_query($conn, "SELECT * FROM clients WHERE id=$id");
$client = mysqli_fetch_assoc($result);
if (!$client) die("Client not found");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? 0;
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';

    $query = "UPDATE clients SET name='$name', email='$email', phone='$phone', address='$address' WHERE id=$id";
    mysqli_query($conn, $query) or die("Update failed: " . mysqli_error($conn));

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Client</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container my-5">
<h2>Edit Client</h2>
<form action="edit.php?id=<?= $client['id'] ?>" method="POST">
<input type="hidden" name="id" value="<?= $client['id'] ?>">
<div class="mb-3">
<label>Name</label>
<input type="text" name="name" class="form-control" value="<?= htmlspecialchars($client['name']) ?>" required>
</div>

<div class="mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" value="<?= htmlspecialchars($client['email']) ?>" required>
</div>

<div class="mb-3">
<label>Phone</label>
<input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($client['phone']) ?>" required>
</div>

<div class="mb-3">
<label>Address</label>
<input type="text" name="address" class="form-control" value="<?= htmlspecialchars($client['address']) ?>" required>
</div>

<button type="submit" class="btn btn-primary">Update Client</button>
<a href="index.php" class="btn btn-secondary">Back</a>
</form>
</div>
</body>
</html>