<!DOCTYPE html>
<html lang="eng">
<head>
<title>My Clients</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container my-5">
<h2>Client List</h2>
<a href="create.php" class="btn btn-primary mb-3">Add New Client</a>
<br>
<table class="table">
<thead>
<tr>
  <td>ID</td>
  <td>Name</td>
  <td>Email</td>
  <td>Phone</td>
  <td>Address</td>
  <td>Created AT</td>
  <td>Action</td>
</tr>
</thead>
<tbody>
<?php
require_once 'db.php';
$sql="SELECT * FROM clients";

$result=mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
        echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['name']}</td>
        <td>{$row['email']}</td>
        <td>{$row['phone']}</td>
        <td>{$row['address']}</td>
        <td>{$row['created_at']}</td>
        <td>
        <a href='edit.php?id={$row['id']}'>Edit</a>
        <a href='delete.php?id={$row['id']}'>delete</a>
        </td>
        </tr>";
    }
}else{
   echo "<tr><td colspan='7' class='text-center'> No clients found</td></tr>";
}

?>
    
</tbody>
</table>
</div>
</body>
</html>